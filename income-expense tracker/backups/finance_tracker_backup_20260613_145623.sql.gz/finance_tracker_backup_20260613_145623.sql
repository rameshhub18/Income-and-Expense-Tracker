-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: finance_tracker
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `action` enum('backup','restore','delete') NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_size` decimal(10,2) DEFAULT NULL,
  `status` enum('success','failed') NOT NULL DEFAULT 'success',
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `backup_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
INSERT INTO `backup_history` VALUES (20,4,'backup','history_cleared',NULL,'success','Backup history cleared','2026-04-30 07:27:55'),(21,5,'delete','finance_tracker_backup_20260430_125518.sql.gz',4.01,'success','Backup deleted','2026-04-30 07:36:58'),(23,4,'delete','test_backup_20260504_134642.sql.gz',4.13,'success','Backup deleted','2026-05-04 08:20:55'),(24,4,'delete','finance_tracker_backup_20260430_130709.sql.gz',3.98,'success','Backup deleted','2026-05-04 08:20:59'),(25,4,'restore','finance_tracker_backup_20260504_135103.sql.gz',3.08,'success','Database restored','2026-05-04 08:30:19'),(30,6,'delete','finance_tracker_backup_20260612_204912.sql.gz',4.09,'success','Backup deleted','2026-06-13 08:52:30'),(31,6,'delete','backups/finance_tracker_backup_20260612_204912.sql.gz',NULL,'failed','File not found','2026-06-13 08:52:33'),(32,6,'delete','finance_tracker_backup_20260504_141443.sql.gz',3.89,'success','Backup deleted','2026-06-13 08:52:35'),(33,6,'delete','backups/finance_tracker_backup_20260504_141443.sql.gz',NULL,'failed','File not found','2026-06-13 08:52:38'),(34,6,'delete','finance_tracker_backup_20260504_140639.sql.gz',3.54,'success','Backup deleted','2026-06-13 08:52:41'),(35,6,'delete','backups/finance_tracker_backup_20260504_140639.sql.gz',NULL,'failed','File not found','2026-06-13 08:52:43'),(36,6,'delete','finance_tracker_backup_20260504_140252.sql.gz',3.50,'success','Backup deleted','2026-06-13 08:52:46'),(37,6,'delete','finance_tracker_backup_20260504_135103.sql.gz',3.08,'success','Backup deleted','2026-06-13 08:52:51'),(38,6,'restore','finance_tracker_backup_20260613_142254.sql.gz',4.64,'success','Database restored','2026-06-13 09:06:54'),(39,6,'backup','finance_tracker_backup_20260613_145619.sql.gz',4.75,'success','Backup created','2026-06-13 09:26:19');
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_metadata`
--

DROP TABLE IF EXISTS `backup_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_metadata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` decimal(10,2) NOT NULL,
  `backup_type` enum('full','incremental') NOT NULL DEFAULT 'full',
  `tables_count` int(10) unsigned DEFAULT NULL,
  `rows_count` int(10) unsigned DEFAULT NULL,
  `compressed` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `backup_metadata_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_metadata`
--

LOCK TABLES `backup_metadata` WRITE;
/*!40000 ALTER TABLE `backup_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_restore_log`
--

DROP TABLE IF EXISTS `backup_restore_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_restore_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `restore_type` enum('full','partial') NOT NULL DEFAULT 'full',
  `tables_restored` int(10) unsigned DEFAULT NULL,
  `rows_restored` int(10) unsigned DEFAULT NULL,
  `status` enum('success','failed','partial') NOT NULL DEFAULT 'success',
  `error_message` text DEFAULT NULL,
  `restored_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_restored_at` (`restored_at`),
  CONSTRAINT `backup_restore_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_restore_log`
--

LOCK TABLES `backup_restore_log` WRITE;
/*!40000 ALTER TABLE `backup_restore_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_restore_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_settings`
--

DROP TABLE IF EXISTS `backup_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `auto_backup_enabled` tinyint(1) DEFAULT 0,
  `backup_frequency` enum('hourly','daily','weekly','monthly') DEFAULT 'daily',
  `max_backups` int(10) unsigned DEFAULT 10,
  `retention_days` int(10) unsigned DEFAULT 30,
  `compression_enabled` tinyint(1) DEFAULT 1,
  `notification_on_backup` tinyint(1) DEFAULT 1,
  `notification_on_restore` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `backup_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_settings`
--

LOCK TABLES `backup_settings` WRITE;
/*!40000 ALTER TABLE `backup_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_statistics`
--

DROP TABLE IF EXISTS `backup_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_statistics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `total_backups` int(11) DEFAULT 0,
  `total_restores` int(11) DEFAULT 0,
  `total_deletes` int(11) DEFAULT 0,
  `total_backup_size` decimal(12,2) DEFAULT 0.00,
  `failed_backups` int(11) DEFAULT 0,
  `failed_restores` int(11) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `backup_statistics_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_statistics`
--

LOCK TABLES `backup_statistics` WRITE;
/*!40000 ALTER TABLE `backup_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budgets`
--

DROP TABLE IF EXISTS `budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `budgets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `category` varchar(80) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `month` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_cat_month` (`user_id`,`category`,`month`),
  CONSTRAINT `budgets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budgets`
--

LOCK TABLES `budgets` WRITE;
/*!40000 ALTER TABLE `budgets` DISABLE KEYS */;
INSERT INTO `budgets` VALUES (20,7,'Food',10000.00,'2026-05-01','2026-05-04 08:44:22'),(22,6,'Entertainment',10000.00,'2026-06-01','2026-06-13 09:21:51'),(23,6,'Bills',50000.00,'2026-06-01','2026-06-13 09:22:44');
/*!40000 ALTER TABLE `budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `type` enum('income','expense','both') NOT NULL DEFAULT 'both',
  `icon` varchar(80) NOT NULL DEFAULT 'ri-price-tag-3-line',
  `color` varchar(20) NOT NULL DEFAULT '#2563eb',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_cat` (`user_id`,`name`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (76,4,'Salary','income','ri-money-dollar-circle-line','#10b981','2026-05-04 08:20:25'),(77,4,'Freelance','income','ri-briefcase-line','#2563eb','2026-05-04 08:20:25'),(78,4,'Food','expense','ri-restaurant-line','#f59e0b','2026-05-04 08:20:25'),(79,4,'Transport','expense','ri-car-line','#6366f1','2026-05-04 08:20:25'),(80,4,'Shopping','expense','ri-shopping-cart-2-line','#ec4899','2026-05-04 08:20:25'),(81,4,'Bills','expense','ri-lightbulb-line','#ef4444','2026-05-04 08:20:25'),(82,4,'Health','expense','ri-heart-pulse-line','#14b8a6','2026-05-04 08:20:25'),(83,4,'Entertainment','expense','ri-gamepad-line','#f97316','2026-05-04 08:20:25'),(84,4,'Other','both','ri-price-tag-3-line','#8b5cf6','2026-05-04 08:20:25'),(94,7,'Salary','income','ri-money-dollar-circle-line','#10b981','2026-05-04 08:43:31'),(95,7,'Freelance','income','ri-briefcase-line','#2563eb','2026-05-04 08:43:31'),(96,7,'Food','expense','ri-restaurant-line','#f59e0b','2026-05-04 08:43:31'),(97,7,'Transport','expense','ri-car-line','#6366f1','2026-05-04 08:43:31'),(98,7,'Shopping','expense','ri-shopping-cart-2-line','#ec4899','2026-05-04 08:43:31'),(99,7,'Bills','expense','ri-lightbulb-line','#ef4444','2026-05-04 08:43:31'),(100,7,'Health','expense','ri-heart-pulse-line','#14b8a6','2026-05-04 08:43:31'),(101,7,'Entertainment','expense','ri-gamepad-line','#f97316','2026-05-04 08:43:31'),(102,7,'Other','both','ri-price-tag-3-line','#8b5cf6','2026-05-04 08:43:31'),(139,6,'Salary','income','ri-money-dollar-circle-line','#10b981','2026-06-12 18:19:44'),(140,6,'Freelance','income','ri-briefcase-line','#2563eb','2026-06-12 18:19:44'),(141,6,'Food','expense','ri-restaurant-line','#f59e0b','2026-06-12 18:19:44'),(142,6,'Transport','expense','ri-car-line','#6366f1','2026-06-12 18:19:44'),(143,6,'Shopping','expense','ri-shopping-cart-2-line','#ec4899','2026-06-12 18:19:44'),(144,6,'Bills','expense','ri-lightbulb-line','#ef4444','2026-06-12 18:19:44'),(145,6,'Health','expense','ri-heart-pulse-line','#14b8a6','2026-06-12 18:19:44'),(146,6,'Entertainment','expense','ri-gamepad-line','#f97316','2026-06-12 18:19:44'),(147,6,'Other','both','ri-price-tag-3-line','#8b5cf6','2026-06-12 18:19:44');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` enum('info','success','warning','error') NOT NULL DEFAULT 'info',
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (53,4,'info','New Login','You logged in on May 04, 2026 at 01:50 PM.',0,'2026-05-04 08:20:25'),(54,4,'success','Income Added: Salary','+₹100,000.00 recorded under Salary on 2026-05-04.',0,'2026-05-04 08:20:43'),(55,4,'info','Expense Added: Bills','-₹5,000.00 recorded under Bills on 2026-05-04.',0,'2026-05-04 08:20:50'),(56,4,'info','Backup Deleted','Deleted: test_backup_20260504_134642.sql.gz',0,'2026-05-04 08:20:55'),(57,4,'warning','Database Restored','Restored from: finance_tracker_backup_20260504_135103.sql.gz',0,'2026-05-04 08:30:19'),(64,7,'success','Welcome to FinTracker!','Hi om! Your account was created successfully. Start by adding your first transaction or setting a budget goal.',0,'2026-05-04 08:43:05'),(65,7,'info','New Login','You logged in on May 04, 2026 at 02:13 PM.',0,'2026-05-04 08:43:31'),(66,7,'success','Income Added: Entertainment','+₹100,000.00 recorded under Entertainment on 2026-05-04.',0,'2026-05-04 08:43:48'),(67,7,'info','Expense Added: Food','-₹8,000.00 recorded under Food on 2026-05-04.',0,'2026-05-04 08:44:00'),(68,7,'success','Budget Set: Food','Monthly budget of ₹10,000.00 set for Food (2026-05).',0,'2026-05-04 08:44:22'),(69,7,'warning','Budget Warning: Food','You\'ve used 80.0% of your ₹10,000.00 budget for Food. Only ₹2,000.00 remaining.',0,'2026-05-04 08:44:22'),(94,6,'warning','Data Reset Complete','All your data has been reset. 29 records were deleted.',0,'2026-06-12 18:19:41'),(95,6,'success','Income Added: Salary','+₹10,000.00 recorded under Salary on 2026-06-05. Note: Events',0,'2026-06-12 18:20:12'),(96,6,'success','Income Added: Food','+₹2,000.00 recorded under Food on 2026-06-06. Note: Cafe',0,'2026-06-12 18:20:40'),(97,6,'success','Income Added: Other','+₹5,000.00 recorded under Other on 2026-06-12. Note: Frnds',0,'2026-06-12 18:21:03'),(98,6,'success','Income Added: Entertainment','+₹500.00 recorded under Entertainment on 2026-06-10. Note: Games',0,'2026-06-12 18:21:48'),(99,6,'info','Transaction Updated: Other','Transaction updated to ₹5,000.00 (income) on 2026-06-07.',0,'2026-06-12 18:22:07'),(100,6,'success','Income Added: Transport','+₹4,000.00 recorded under Transport on 2026-06-11. Note: Car Rent',0,'2026-06-12 18:22:40'),(101,6,'success','Income Added: Freelance','+₹3,500.00 recorded under Freelance on 2026-06-09. Note: Editing',0,'2026-06-12 18:23:05'),(102,6,'info','Expense Added: Other','-₹500.00 recorded under Other on 2026-06-12. Note: Vimal',0,'2026-06-12 18:23:23'),(103,6,'info','Expense Added: Bills','-₹5,000.00 recorded under Bills on 2026-06-06. Note: Room Rent',0,'2026-06-12 18:23:50'),(104,6,'info','Expense Added: Shopping','-₹2,000.00 recorded under Shopping on 2026-06-12. Note: Vishal MM',0,'2026-06-12 18:24:13'),(105,6,'info','Expense Added: Food','-₹950.00 recorded under Food on 2026-06-09. Note: De Cafe',0,'2026-06-12 18:24:38'),(106,6,'info','Expense Added: Health','-₹1,000.00 recorded under Health on 2026-06-10. Note: Fever',0,'2026-06-12 18:25:39'),(107,6,'info','Transaction Updated: Shopping','Transaction updated to ₹2,000.00 (expense) on 2026-06-05.',0,'2026-06-12 18:27:14'),(108,6,'info','New Login','You logged in on Jun 13, 2026 at 01:54 PM.',0,'2026-06-13 08:24:30'),(109,6,'info','Backup Deleted','Deleted: finance_tracker_backup_20260612_204912.sql.gz',0,'2026-06-13 08:52:30'),(110,6,'warning','Database Restored','Restored from: finance_tracker_backup_20260613_142254.sql.gz',0,'2026-06-13 09:06:55'),(111,6,'success','Budget Set: Food','Monthly budget of ₹10,000.00 set for Food (2026-06).',0,'2026-06-13 09:21:51'),(112,6,'success','Budget Set: Bills','Monthly budget of ₹50,000.00 set for Bills (2026-06).',0,'2026-06-13 09:22:44'),(113,6,'success','Backup Created','Backup: finance_tracker_backup_20260613_145619.sql.gz',0,'2026-06-13 09:26:19');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reset_history`
--

DROP TABLE IF EXISTS `reset_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reset_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `action` varchar(50) NOT NULL,
  `records_deleted` int(10) unsigned DEFAULT 0,
  `status` enum('success','failed') NOT NULL DEFAULT 'success',
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reset_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reset_history`
--

LOCK TABLES `reset_history` WRITE;
/*!40000 ALTER TABLE `reset_history` DISABLE KEYS */;
INSERT INTO `reset_history` VALUES (1,4,'full_reset',15,'success','Deleted: 2 transactions, 1 budgets, 9 categories, 3 notifications, 0 backup records','2026-05-04 05:08:46'),(2,4,'full_reset',11,'success','Deleted: 0 transactions, 0 budgets, 9 categories, 2 notifications, 0 backup records','2026-05-04 05:19:08'),(3,7,'full_reset',15,'success','Deleted: 2 transactions, 0 budgets, 9 categories, 4 notifications, 0 backup records','2026-05-04 08:06:46'),(4,6,'full_reset',25,'success','Deleted: 3 transactions, 1 budgets, 9 categories, 9 notifications, 3 backup records','2026-05-18 05:18:42'),(5,6,'full_reset',15,'success','Deleted: 2 transactions, 0 budgets, 9 categories, 4 notifications, 0 backup records','2026-05-30 13:28:47'),(6,6,'full_reset',15,'success','Deleted: 1 transactions, 0 budgets, 9 categories, 5 notifications, 0 backup records','2026-06-11 17:37:12'),(7,6,'full_reset',11,'success','Deleted: 0 transactions, 0 budgets, 9 categories, 2 notifications, 0 backup records','2026-06-12 05:10:05'),(8,6,'full_reset',29,'success','Deleted: 8 transactions, 1 budgets, 9 categories, 10 notifications, 1 backup records','2026-06-12 18:19:41');
/*!40000 ALTER TABLE `reset_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` enum('income','expense') NOT NULL,
  `category` varchar(80) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (34,4,'income','Salary',100000.00,NULL,'2026-05-04','2026-05-04 08:20:43'),(35,4,'expense','Bills',5000.00,NULL,'2026-05-04','2026-05-04 08:20:50'),(39,7,'income','Entertainment',100000.00,NULL,'2026-05-04','2026-05-04 08:43:48'),(40,7,'expense','Food',8000.00,NULL,'2026-05-04','2026-05-04 08:44:00'),(52,6,'income','Salary',10000.00,'Events','2026-06-05','2026-06-12 18:20:12'),(53,6,'income','Food',2000.00,'Cafe','2026-06-06','2026-06-12 18:20:40'),(54,6,'income','Other',5000.00,'Frnds','2026-06-07','2026-06-12 18:21:03'),(55,6,'income','Other',5000.00,'Family','2026-06-10','2026-06-12 18:21:21'),(56,6,'income','Entertainment',500.00,'Games','2026-06-10','2026-06-12 18:21:48'),(57,6,'income','Transport',4000.00,'Car Rent','2026-06-11','2026-06-12 18:22:40'),(58,6,'income','Freelance',3500.00,'Editing','2026-06-09','2026-06-12 18:23:05'),(59,6,'expense','Other',500.00,'Vimal','2026-06-08','2026-06-12 18:23:23'),(60,6,'expense','Bills',5000.00,'Room Rent','2026-06-06','2026-06-12 18:23:50'),(61,6,'expense','Shopping',2000.00,'Vishal MM','2026-06-05','2026-06-12 18:24:13'),(62,6,'expense','Food',950.00,'De Cafe','2026-06-09','2026-06-12 18:24:38'),(63,6,'expense','Other',4000.00,'Internship','2026-06-11','2026-06-12 18:25:04'),(64,6,'expense','Other',700.00,'Project','2026-06-12','2026-06-12 18:25:17'),(65,6,'expense','Health',1000.00,'Fever','2026-06-10','2026-06-12 18:25:39'),(66,6,'expense','Bills',10000.00,'Laptop','2026-06-05','2026-06-12 18:26:00');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'vrush','vrush@gmail.com','$2y$10$WaEWgkeoqfZ8A6wRswZS1.KUmHxa0F8q4LJdCtpUYQzFstp3wmOma','2026-04-17 08:17:01','2026-04-17 08:17:01'),(2,'Ramesh Bellubbi','ram123@gmail.com','$2b$12$/33q3r1COKh3ecFm3TDuZOlniZnnHGlQcUov8nOk2g1r/6yDWcDHW','2026-04-21 08:25:09','2026-04-21 08:25:09'),(3,'abc','abc@email.com','$2b$12$fSnm5QGgV.R8rSKFDfdLiukri1T8Tmw//sRpHJhneZAqXj8aexcmq','2026-04-22 08:15:30','2026-04-22 08:15:30'),(4,'xyz','xyz@gmail.com','$2b$12$90M.mzrGRoKp9vrRWYf5Su9mkVWavSjAjqaFq9bpK/5C68Qi9rKOy','2026-04-23 08:44:10','2026-04-23 08:44:10'),(5,'Ramesh','Ramesh@gmail.com','$2b$12$enlBxW7UQL5EOt3iSmHbd.sHvTsQu9VBo97X2lx7J0tvD7ukaqZ5i','2026-04-30 07:30:10','2026-04-30 07:30:10'),(6,'ram','ram@gmail.com','$2b$12$K8MdVshmDbDGPNP0HRwhVeKU6Ad3EBowdWgv4iEbuQotgShVLbJoK','2026-05-04 08:31:32','2026-05-04 08:31:32'),(7,'om','om@gmail.com','$2b$12$LBlFnl/ZrP9jVi0VN43W4Ot21xBIsqIUtqgePcJJ9yBEpJ2jnHrEG','2026-05-04 08:43:05','2026-05-04 08:43:05');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-13 14:56:23
